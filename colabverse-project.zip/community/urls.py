"""
URL routes for ColabVerse private development groups.

Features:
- Private invitation-only development groups
- Owner-sent invitations
- Group chat
- Group membership management
- GitHub repository integration
- Repository connection approval requests
- Meeting rooms
- LiveKit voice/video meeting actions
- Screen-sharing permission requests and approvals
"""

from django.urls import path

# LiveKit webhook endpoint.
from .livekit_webhooks import livekit_webhook_view

# Group dashboard, chat, and repositories.
from . import views

# Private-group invitations.
from . import invitation_views

# GitHub repository connection approvals.
from . import repository_request_views

# LiveKit meeting actions.
from . import meeting_views


urlpatterns = [

    # ========================================================
    # 1. GROUP DASHBOARD
    # ========================================================

    path(
        "",
        views.groups,
        name="groups",
    ),

    # ========================================================
    # 2. CREATE PRIVATE DEVELOPMENT GROUP
    # ========================================================

    path(
        "create/",
        views.create_group,
        name="create_group",
    ),

    # ========================================================
    # 3. GROUP DETAILS
    # ========================================================

    path(
        "<int:group_id>/",
        views.group_detail,
        name="group_detail",
    ),

    # ========================================================
    # 4. PRIVATE-GROUP INVITATIONS
    # ========================================================

    path(
        "<int:group_id>/invitations/send/",
        invitation_views.send_invitation_view,
        name="send_group_invitation",
    ),

    path(
        "invitations/received/",
        invitation_views.received_invitations_view,
        name="received_group_invitations",
    ),

    path(
        "invitations/<int:invitation_id>/accept/",
        invitation_views.accept_invitation_view,
        name="accept_group_invitation",
    ),

    path(
        "invitations/<int:invitation_id>/decline/",
        invitation_views.decline_invitation_view,
        name="decline_group_invitation",
    ),

    # ========================================================
    # 5. GROUP MEMBERSHIP MANAGEMENT
    # ========================================================

    path(
        "<int:group_id>/members/search/",
        views.search_group_developers,
        name="search_group_developers",
    ),

    path(
        "<int:group_id>/members/<int:member_id>/remove/",
        views.remove_group_member,
        name="remove_group_member",
    ),

    path(
        "<int:group_id>/members/leave/",
        views.leave_group,
        name="leave_group",
    ),

    # ========================================================
    # 6. GROUP CHAT
    # ========================================================

    path(
        "<int:group_id>/chat/",
        views.group_chat,
        name="group_chat",
    ),

    path(
        "<int:group_id>/chat/send/",
        views.send_group_message,
        name="send_group_message",
    ),

    path(
        "<int:group_id>/chat/<int:message_id>/edit/",
        views.edit_group_message,
        name="edit_group_message",
    ),

    path(
        "<int:group_id>/chat/<int:message_id>/delete/",
        views.delete_group_message,
        name="delete_group_message",
    ),

    # ========================================================
    # 7. GROUP CHAT MESSAGE REACTIONS
    # ========================================================

    path(
        "<int:group_id>/chat/<int:message_id>/react/",
        views.toggle_group_message_reaction,
        name="toggle_group_message_reaction",
    ),

    # ========================================================
    # 8. SECURE GROUP CHAT ATTACHMENT DOWNLOAD
    # ========================================================

    path(
        "<int:group_id>/chat/<int:message_id>/attachment/",
        views.download_group_attachment,
        name="download_group_attachment",
    ),

    # ========================================================
    # 9. GITHUB REPOSITORY INTEGRATION
    # ========================================================

    path(
        "<int:group_id>/repository/connect/",
        views.connect_group_repository,
        name="connect_group_repository",
    ),

    # Member requests permission to connect a repository.
    path(
        "<int:group_id>/repository/request/",
        repository_request_views.request_repository_connection,
        name="request_repository_connection",
    ),

    # Group owner approves a repository connection request.
    path(
        "<int:group_id>/repository/requests/<int:request_id>/approve/",
        repository_request_views.approve_repository_connection,
        name="approve_repository_connection",
    ),

    # Group owner rejects a repository connection request.
    path(
        "<int:group_id>/repository/requests/<int:request_id>/reject/",
        repository_request_views.reject_repository_connection,
        name="reject_repository_connection",
    ),

    path(
        "<int:group_id>/repository/files/",
        views.group_repository_files,
        name="group_repository_files",
    ),

    path(
        "<int:group_id>/repository/file-content/",
        views.group_repository_file_content,
        name="group_repository_file_content",
    ),

    # ========================================================
    # 10. PRIVATE-GROUP MEETING ROOM
    # ========================================================

    path(
        "<int:group_id>/meeting/",
        views.meeting_room,
        name="meeting_room",
    ),

    # ========================================================
    # 11. LIVEKIT MEETING ACTIONS
    # ========================================================

    # Any accepted member can start a meeting.
    path(
        "<int:group_id>/meeting/start/",
        meeting_views.start_meeting_view,
        name="start_group_meeting",
    ),

    # Any accepted member can join an active meeting.
    path(
        "<int:group_id>/meeting/join/",
        meeting_views.join_meeting_view,
        name="join_group_meeting",
    ),

    # Only the creator or group owner can end a meeting.
    path(
        "<int:group_id>/meeting/end/",
        meeting_views.end_meeting_view,
        name="end_group_meeting",
    ),

    # ========================================================
    # 12. CHECK ACTIVE MEETING STATUS
    # ========================================================

    # Check whether a meeting is active and repository
    # modifications should remain locked.
    path(
        "<int:group_id>/meeting/status/",
        meeting_views.meeting_status_view,
        name="group_meeting_status",
    ),

    # ========================================================
    # 13. SCREEN-SHARING PERMISSION REQUESTS
    # ========================================================

    # A group member requests permission to share their screen.
    path(
        "<int:group_id>/meeting/screen-share/request/",
        meeting_views.request_screen_share_view,
        name="request_group_screen_share",
    ),

    # Only the meeting creator can approve a pending request.
    path(
        "<int:group_id>/meeting/screen-share/<int:request_id>/approve/",
        meeting_views.approve_screen_share_view,
        name="approve_group_screen_share",
    ),

    # Only the meeting creator can reject a pending request.
    path(
        "<int:group_id>/meeting/screen-share/<int:request_id>/reject/",
        meeting_views.reject_screen_share_view,
        name="reject_group_screen_share",
    ),

    # A developer cancels their own pending request.
    path(
        "<int:group_id>/meeting/screen-share/<int:request_id>/cancel/",
        meeting_views.cancel_screen_share_view,
        name="cancel_group_screen_share",
    ),

    # ========================================================
    # 14. RELEASE SCREEN-SHARING PERMISSION
    # ========================================================

    # An approved presenter releases their screen-sharing slot.
    #
    # Django verifies ownership of the slot.
    # LiveKit verifies that screen sharing has stopped.
    # Permission returns to the meeting creator when safe.
    path(
        "<int:group_id>/meeting/screen-share/release/",
        meeting_views.release_screen_share_view,
        name="release_group_screen_share",
    ),

    # ========================================================
    # 15. SCREEN-SHARING PERMISSION STATE
    # ========================================================

    # Allow accepted group members to retrieve their current
    # screen-sharing permissions.
    #
    # Only the meeting creator receives pending requests.
    # This endpoint does not grant LiveKit permissions.
    path(
        "<int:group_id>/meeting/screen-share/state/",
        meeting_views.screen_share_permission_state_view,
        name="group_screen_share_state",
    ),

    # ========================================================
    # 16. LIVEKIT WEBHOOK
    # ========================================================

    path(
        "webhooks/livekit/",
        livekit_webhook_view,
        name="livekit_webhook",
    ),

]
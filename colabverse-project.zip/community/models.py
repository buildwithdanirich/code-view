"""Database models for ColabVerse groups, memberships, and collaboration."""

import uuid

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models, transaction

from .storage import PrivateGroupStorage
# ============================================================
# 1. PROJECT GROUP
# ============================================================

class ProjectGroup(models.Model):
    """Store normal chat groups and private development groups."""

    JOIN_POLICY_CHOICES = [
        ("open", "Anyone Can Join"),
        ("approval", "Admin Approval Required"),
        ("invite", "Invitation Only"),
    ]

    name = models.CharField(max_length=100)
    description = models.TextField()

    # Developer who owns the group.
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="owned_project_groups",
    )

    # Helps invalidate old owner permissions if ownership changes.
    owner_membership_generation = models.UUIDField(
        default=uuid.uuid4,
        editable=False,
    )

    # False = normal chat group.
    # True = private development group.
    is_private = models.BooleanField(default=False)

    # Existing join policies are retained for migration compatibility.
    join_policy = models.CharField(
        max_length=10,
        choices=JOIN_POLICY_CHOICES,
        default="open",
    )

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def clean(self):
        """Prevent unrestricted joining of private groups."""
        super().clean()

        if self.is_private and self.join_policy == "open":
            raise ValidationError({
                "join_policy": (
                    "Private development groups must require "
                    "an invitation or approval."
                )
            })

    def save(self, *args, **kwargs):
        """Validate group settings before saving."""
        self.full_clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


# ============================================================
# 2. GROUP MEMBER
# ============================================================

class GroupMember(models.Model):
    """Store group members and their existing roles."""

    ROLE_CHOICES = [
        ("admin", "Admin"),
        ("member", "Member"),
    ]

    group = models.ForeignKey(
        ProjectGroup,
        on_delete=models.CASCADE,
        related_name="memberships",
    )

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
    )

    role = models.CharField(
        max_length=10,
        choices=ROLE_CHOICES,
        default="member",
    )

    joined_at = models.DateTimeField(auto_now_add=True)

    # Identifies the current membership period.
    membership_generation = models.UUIDField(
        default=uuid.uuid4,
        editable=False,
    )

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["group", "user"],
                name="unique_project_group_member",
            ),
        ]

    def clean(self):
        """
        Enforce the private-group limit.

        Maximum:
            1 owner + 9 other developers = 10 people.

        Normal chat groups have no fixed membership limit.
        """
        super().clean()

        if not self.group_id:
            return

        # Normal groups have no fixed limit.
        if not self.group.is_private:
            return

        # Count members other than the owner.
        members = GroupMember.objects.filter(
            group_id=self.group_id,
        ).exclude(
            user_id=self.group.owner_id,
        )

        # Do not count the current record twice during an update.
        if self.pk:
            members = members.exclude(pk=self.pk)

        # The owner is counted separately.
        if self.user_id == self.group.owner_id:
            return

        if members.count() >= 9:
            raise ValidationError(
                "Private development groups cannot exceed "
                "10 people, including the owner."
            )

    def save(self, *args, **kwargs):
        """
        Save memberships safely.

        Lock the parent group so simultaneous membership saves
        cannot independently pass the capacity check.
        """

        database = (
            kwargs.get("using")
            or self._state.db
            or "default"
        )

        with transaction.atomic(using=database):

            if self.group_id:
                locked_group = (
                    ProjectGroup.objects.using(database)
                    .select_for_update()
                    .get(pk=self.group_id)
                )

                self.group = locked_group

            # Validate while holding the database lock.
            self.full_clean()

            # Save inside the same transaction.
            super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.user} in {self.group.name}"


# ============================================================
# 3. EXISTING GROUP MEMBERSHIP REQUEST
# ============================================================

class GroupMembershipRequest(models.Model):
    """
    Legacy membership-request model.

    Keep this temporarily because existing views and migrations
    may still reference it.

    We will remove the old approval workflow after updating
    the remaining CodeView files.
    """

    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("approved", "Approved"),
        ("rejected", "Rejected"),
    ]

    group = models.ForeignKey(
        ProjectGroup,
        on_delete=models.CASCADE,
        related_name="membership_requests",
    )

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="group_join_requests",
    )

    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default="pending",
    )

    message = models.TextField(
        max_length=1000,
        blank=True,
    )

    reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="reviewed_group_requests",
    )

    created_at = models.DateTimeField(auto_now_add=True)

    reviewed_at = models.DateTimeField(
        null=True,
        blank=True,
    )

    class Meta:
        ordering = ["-created_at"]

        constraints = [
            models.UniqueConstraint(
                fields=["group", "user"],
                name="unique_group_membership_request",
            ),
        ]

        indexes = [
            models.Index(
                fields=["group", "status", "created_at"],
                name="group_request_status_idx",
            ),
        ]

    def clean(self):
        """Validate legacy membership requests."""
        super().clean()

        if not self.group_id or not self.user_id:
            return

        already_member = GroupMember.objects.filter(
            group_id=self.group_id,
            user_id=self.user_id,
        ).exists()

        if already_member:
            raise ValidationError(
                "This developer is already a member of the group."
            )

        if self.group.join_policy == "invite":
            raise ValidationError(
                "This group can only be joined through an invitation."
            )

    def save(self, *args, **kwargs):
        """Validate before saving."""
        self.full_clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return (
            f"{self.user} requested to join "
            f"{self.group.name}: {self.status}"
        )


# ============================================================
# 4. NEW GROUP INVITATION
# ============================================================

class GroupInvitation(models.Model):
    """
    Store invitations sent by private development group owners.

    Workflow:
        1. Owner invites a developer.
        2. Invitation starts as pending.
        3. Developer accepts or declines.
        4. Accepted invitations lead to group membership.

    The acceptance workflow will be implemented separately.
    """

    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("accepted", "Accepted"),
        ("declined", "Declined"),
    ]

    # Private development group sending the invitation.
    group = models.ForeignKey(
        ProjectGroup,
        on_delete=models.CASCADE,
        related_name="invitations",
    )

    # Developer who sent the invitation.
    # This must be the group owner.
    invited_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="sent_group_invitations",
    )

    # Developer receiving the invitation.
    invited_user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="received_group_invitations",
    )

    # pending, accepted, or declined.
    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default="pending",
    )

    # When the invitation was created.
    created_at = models.DateTimeField(auto_now_add=True)

    # When the developer accepted or declined.
    responded_at = models.DateTimeField(
        null=True,
        blank=True,
    )

    class Meta:
        ordering = ["-created_at"]

        constraints = [
            # Prevent duplicate invitation records for one
            # developer in the same group.
            models.UniqueConstraint(
                fields=["group", "invited_user"],
                name="unique_private_group_invitation",
            ),
        ]

        indexes = [
            # Make finding pending invitations faster.
            models.Index(
                fields=["invited_user", "status"],
                name="group_invitee_status_idx",
            ),
        ]

    def clean(self):
        """Validate the invitation before saving it."""

        super().clean()

        # Make sure the required relationships exist.
        if (
            not self.group_id
            or not self.invited_by_id
            or not self.invited_user_id
        ):
            return

        # Only private groups can send invitations.
        if not self.group.is_private:
            raise ValidationError(
                "Only private development groups use invitations."
            )

        # Only the group owner can send invitations.
        if self.invited_by_id != self.group.owner_id:
            raise ValidationError(
                "Only the group owner can send invitations."
            )

        # The owner cannot invite themselves.
        if self.invited_user_id == self.group.owner_id:
            raise ValidationError(
                "The group owner cannot invite themselves."
            )

        # Prevent inviting an existing member.
        if self.status == "pending":

            already_member = GroupMember.objects.filter(
                group_id=self.group_id,
                user_id=self.invited_user_id,
            ).exists()

            if already_member:
                raise ValidationError(
                    "This developer is already a member of the group."
                )

    def save(self, *args, **kwargs):
        """Validate invitation data before saving."""
        self.full_clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return (
            f"Invitation for {self.invited_user} "
            f"to {self.group.name}: {self.status}"
        )


# ============================================================
# 9. GROUP REPOSITORY
# ============================================================
class GroupRepository(models.Model):
    """
    Store GitHub repository information for private groups.

    Supports:
    - Existing public repository connections
    - GitHub App-authorized private repositories
    """

    # Each private development group can connect one repository.
    group = models.OneToOneField(
        ProjectGroup,
        on_delete=models.CASCADE,
        related_name="repository",
    )

    # GitHub username or organization that owns the repository.
    github_owner = models.CharField(
        max_length=100,
    )

    # Repository name.
    repository_name = models.CharField(
        max_length=100,
    )

    # Repository's default branch.
    default_branch = models.CharField(
        max_length=100,
        default="main",
    )

    # GitHub's unique repository ID.
    # Null supports existing repository records.
    github_repository_id = models.BigIntegerField(
        null=True,
        blank=True,
    )

    # GitHub App installation ID.
    # Null means no installation is linked to this record.
    github_installation_id = models.BigIntegerField(
        null=True,
        blank=True,
    )

    # Whether GitHub identifies this repository as private.
    is_private = models.BooleanField(
        default=False,
    )

    # Date when the repository was connected.
    connected_at = models.DateTimeField(
        auto_now_add=True,
    )

    def clean(self):
        """
        Validate repository information.
        """

        super().clean()

        # Only private development groups can connect repositories.
        if self.group_id and not self.group.is_private:
            raise ValidationError(
                "Only private development groups can connect repositories."
            )

        # Private repositories require a GitHub App installation.
        if self.is_private and not self.github_installation_id:
            raise ValidationError(
                "Private repositories require GitHub App authorization."
            )

        # An authorized private repository must have a stable GitHub ID.
        if self.is_private and not self.github_repository_id:
            raise ValidationError(
                "Private repositories require a GitHub repository ID."
            )

    def save(self, *args, **kwargs):
        """
        Validate repository information before saving.
        """

        self.full_clean()

        super().save(*args, **kwargs)

    def __str__(self):
        """
        Display the repository's owner and name.
        """

        return f"{self.github_owner}/{self.repository_name}"
# ============================================================
# 10. GROUP CHAT MESSAGE
# ============================================================

class GroupChatMessage(models.Model):
    """
    Store messages sent inside normal and private groups.

    Supports:
        - Text messages
        - Code snippets
        - Voice notes
        - File attachments
        - Replies
        - Message editing
        - Soft deletion
    """

    MESSAGE_TYPES = [
        ("text", "Text"),
        ("code", "Code Snippet"),
        ("voice", "Voice Note"),
        ("file", "Attachment"),
    ]

    # Group receiving the message.
    group = models.ForeignKey(
        ProjectGroup,
        on_delete=models.CASCADE,
        related_name="chat_messages",
    )

    # Keep chat history when the sender account is deleted.
    sender = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        related_name="group_chat_messages",
    )

    # Identify the message type.
    message_type = models.CharField(
        max_length=10,
        choices=MESSAGE_TYPES,
        default="text",
    )

    # Ordinary text or programming code.
    content = models.TextField(
        blank=True,
    )

    # Programming language for code snippets.
    code_language = models.CharField(
        max_length=30,
        blank=True,
    )
    # Store chat attachments privately.
    # Access is controlled by download_group_attachment().
    attachment = models.FileField(
        upload_to="group_chat/attachments/%Y/%m/",
        storage=PrivateGroupStorage(),
        blank=True,
    )

    # A message can reply to another message.
    reply_to = models.ForeignKey(
        "self",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="chat_replies",
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
    )

    # Time of the most recent edit.
    edited_at = models.DateTimeField(
        null=True,
        blank=True,
    )

    # Soft deletion preserves message references.
    deleted_at = models.DateTimeField(
        null=True,
        blank=True,
    )

    class Meta:
        ordering = ["created_at", "id"]

        indexes = [
            models.Index(
                fields=["group", "created_at", "id"],
            ),
        ]

    def clean(self):
        """Validate messages and their reply relationships."""
        super().clean()

        if self.reply_to_id:

            # A message cannot reply to itself.
            if self.pk and self.reply_to_id == self.pk:
                raise ValidationError(
                    "A message cannot reply to itself."
                )

            # Replies cannot cross group boundaries.
            if self.reply_to.group_id != self.group_id:
                raise ValidationError(
                    "Replies must stay within the same group."
                )

        # Deleted messages remain stored.
        if self.deleted_at:
            return

        # Text and code messages require content.
        if self.message_type in ("text", "code"):

            if not self.content.strip():
                raise ValidationError(
                    "Text and code messages require content."
                )

        # Voice notes and file messages require attachments.
        if self.message_type in ("voice", "file"):

            if not self.attachment:
                raise ValidationError(
                    "Voice and file messages require an attachment."
                )

    def save(self, *args, **kwargs):
        """Validate messages before saving."""
        self.full_clean()
        super().save(*args, **kwargs)

    def __str__(self):

        sender = (
            self.sender.username
            if self.sender
            else "Deleted user"
        )

        return (
            f"{sender} in {self.group.name} "
            f"({self.message_type})"
        )


        # ============================================================
# 11. GROUP MESSAGE REACTION
# ============================================================

class GroupMessageReaction(models.Model):
    """
    Store emoji reactions to group chat messages.

    Rules:
        - Each developer can have one reaction per message.
        - Developers can change their reaction.
        - Developers can remove their reaction.
        - Reactions belong to a specific message.
    """

    # Supported emoji reactions.
    REACTION_CHOICES = [
        ("👍", "Like"),
        ("❤️", "Love"),
        ("😂", "Laugh"),
        ("🔥", "Fire"),
        ("😮", "Surprised"),
        ("😢", "Sad"),
    ]

    # Message receiving the reaction.
    message = models.ForeignKey(
        GroupChatMessage,
        on_delete=models.CASCADE,
        related_name="reactions",
    )

    # Developer who reacted.
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="group_message_reactions",
    )

    # Emoji selected by the developer.
    emoji = models.CharField(
        max_length=10,
        choices=REACTION_CHOICES,
    )

    # When the reaction was created.
    created_at = models.DateTimeField(
        auto_now_add=True,
    )

    class Meta:

        # Prevent one developer from creating
        # multiple reactions on the same message.
        constraints = [
            models.UniqueConstraint(
                fields=["message", "user"],
                name="unique_group_message_reaction",
            ),
        ]

    def clean(self):
        """Validate the reaction before saving."""

        super().clean()

        if not self.message_id or not self.user_id:
            return

        # Deleted messages cannot receive reactions.
        if self.message.deleted_at:
            raise ValidationError(
                "Cannot react to a deleted message."
            )

        # Only group members or the owner can react.
        is_owner = (
            self.message.group.owner_id == self.user_id
        )

        is_member = GroupMember.objects.filter(
            group_id=self.message.group_id,
            user_id=self.user_id,
        ).exists()

        if not is_owner and not is_member:
            raise ValidationError(
                "Only group members can react to messages."
            )

    def save(self, *args, **kwargs):
        """Validate the reaction before saving."""

        self.full_clean()

        super().save(*args, **kwargs)

    def __str__(self):

        return (
            f"{self.user} reacted {self.emoji} "
            f"to message {self.message_id}"
        )

        # ============================================================
# REPOSITORY CONNECTION REQUEST
# ============================================================

class RepositoryConnectionRequest(models.Model):
    """
    Track requests from members who want to replace
    their private development group's GitHub repository.

    The group owner must approve the request before
    the member can begin connecting a repository.
    """

    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("approved", "Approved"),
        ("rejected", "Rejected"),
        ("used", "Used"),
        ("cancelled", "Cancelled"),
    ]

    # The private development group.
    group = models.ForeignKey(
        ProjectGroup,
        on_delete=models.CASCADE,
        related_name="repository_connection_requests",
    )

    # Member requesting permission.
    requested_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="repository_connection_requests",
    )

    # Current state of the request.
    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default="pending",
    )

    # Identifies the membership period when the request was created.
    membership_generation = models.UUIDField()

    # Identifies the group ownership period.
    owner_membership_generation = models.UUIDField()

    # Group owner who reviewed the request.
    reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="reviewed_repository_connection_requests",
    )

    # When the member submitted the request.
    created_at = models.DateTimeField(
        auto_now_add=True,
    )

    # When the owner approved or rejected the request.
    reviewed_at = models.DateTimeField(
        null=True,
        blank=True,
    )

    # When an approved request was successfully used.
    used_at = models.DateTimeField(
        null=True,
        blank=True,
    )

    class Meta:
        ordering = ["-created_at"]

        indexes = [
            models.Index(
                fields=["group", "status"],
                name="repo_request_group_status_idx",
            ),
        ]

        constraints = [
            # A member cannot have two pending requests
            # for the same group.
            models.UniqueConstraint(
                fields=["group", "requested_by"],
                condition=models.Q(status="pending"),
                name="unique_pending_repo_request",
            ),

            # A member cannot have two approved,
            # unused requests for the same group.
            models.UniqueConstraint(
                fields=["group", "requested_by"],
                condition=models.Q(status="approved"),
                name="unique_approved_repo_request",
            ),
        ]

    def clean(self):
        """
        Validate repository connection requests.

        Security rules:
        - Pending and approved requests require current membership.
        - Pending and approved requests must belong to the
          current membership and ownership generations.
        - Historical requests can remain saved even when
          membership or ownership changes.
        """

        super().clean()

        if not self.group_id or not self.requested_by_id:
            return

        # --------------------------------------------------------
        # 1. VERIFY THE GROUP TYPE
        # --------------------------------------------------------

        if not self.group.is_private:
            raise ValidationError(
                "Repository connection requests are only "
                "allowed in private development groups."
            )

        # --------------------------------------------------------
        # 2. HISTORICAL REQUESTS
        # --------------------------------------------------------

        # These statuses do not grant repository permissions.
        # Allow historical records to be saved even when
        # the developer's membership is no longer valid.
        if self.status in ("rejected", "cancelled", "used"):
            return

        # --------------------------------------------------------
        # 3. OWNER CANNOT REQUEST PERMISSION
        # --------------------------------------------------------

        if self.requested_by_id == self.group.owner_id:
            raise ValidationError(
                "Group owners do not need repository "
                "connection approval."
            )

        # --------------------------------------------------------
        # 4. VERIFY CURRENT MEMBERSHIP
        # --------------------------------------------------------

        membership = GroupMember.objects.filter(
            group_id=self.group_id,
            user_id=self.requested_by_id,
        ).first()

        if membership is None:
            raise ValidationError(
                "Only current group members can request "
                "repository connection permission."
            )

        # --------------------------------------------------------
        # 5. VERIFY MEMBERSHIP GENERATION
        # --------------------------------------------------------

        if (
            self.membership_generation
            != membership.membership_generation
        ):
            raise ValidationError(
                "Repository connection request membership "
                "is no longer valid."
            )

        # --------------------------------------------------------
        # 6. VERIFY OWNERSHIP GENERATION
        # --------------------------------------------------------

        if (
            self.owner_membership_generation
            != self.group.owner_membership_generation
        ):
            raise ValidationError(
                "Repository connection request ownership "
                "is no longer valid."
            )

    def save(self, *args, **kwargs):
        """Validate before saving the request."""

        self.full_clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return (
            f"{self.requested_by} - {self.group.name} "
            f"({self.status})"
        )

# ============================================================
# 12. PRIVATE GROUP LIVEKIT MEETING
# ============================================================

class GroupMeeting(models.Model):
    """Track LiveKit meetings for private development groups.

    PostgreSQL guarantees at most one active meeting per group.
    LiveKit room capacity and participant permissions are enforced
    separately by the meeting service and LiveKit.
    """

    STATUS_CHOICES = [
        ("active", "Active"),
        ("ended", "Ended"),
    ]

    group = models.ForeignKey(
        ProjectGroup,
        on_delete=models.CASCADE,
        related_name="meetings",
    )

    # A UUID is a unique, unguessable room identifier.
    room_name = models.UUIDField(
        default=uuid.uuid4,
        unique=True,
        editable=False,
    )

    started_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="started_group_meetings",
    )

        # ========================================================
    # SCREEN-SHARING PERMISSION
    # ========================================================

    # The developer currently assigned the screen-sharing slot.
    # Only one developer can occupy this field at a time.
    active_screen_sharer = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="active_screen_sharing_meetings",
    )

    # Tracks the process of granting or removing LiveKit access.
    SCREEN_SHARE_STATE_CHOICES = [
        ("idle", "Idle"),
        ("granting", "Granting Permission"),
        ("ready", "Ready to Share"),
        ("revoking", "Revoking Permission"),
    ]

    screen_share_state = models.CharField(
        max_length=10,
        choices=SCREEN_SHARE_STATE_CHOICES,
        default="idle",
    )

    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default="active",
    )

    started_at = models.DateTimeField(auto_now_add=True)

    ended_at = models.DateTimeField(
        null=True,
        blank=True,
    )

    class Meta:
        ordering = ["-started_at"]
        constraints = [
            models.UniqueConstraint(
                fields=["group"],
                condition=models.Q(status="active"),
                name="unique_active_group_meeting",
            ),
        ]

    def clean(self):
        """Allow private-group members to create meetings."""
        super().clean()

        if not self.group_id or not self.started_by_id:
            return

        if not self.group.is_private:
            raise ValidationError(
                "Only private development groups can have meetings."
            )

        # Check membership when creating a meeting. Historical meeting
        # records remain valid if the creator later leaves the group.
        if self._state.adding:
            is_owner = self.started_by_id == self.group.owner_id
            is_member = GroupMember.objects.filter(
                group_id=self.group_id,
                user_id=self.started_by_id,
            ).exists()

            if not is_owner and not is_member:
                raise ValidationError(
                    "Only current private group members can start a meeting."
                )

        if self.status == "active" and self.ended_at is not None:
            raise ValidationError(
                "An active meeting cannot have an end time."
            )

        if self.status == "ended" and self.ended_at is None:
            raise ValidationError(
                "An ended meeting must have an end time."
            )

    def save(self, *args, **kwargs):
        """Validate meeting records before saving."""
        self.full_clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.group.name} meeting ({self.status})"


# ============================================================
#  SCREEN-SHARING REQUESTS
# ============================================================

class MeetingScreenShareRequest(models.Model):
    """
    Store requests from developers who want to share
    their screens during a private group meeting.
    """

    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("approved", "Approved"),
        ("rejected", "Rejected"),
        ("cancelled", "Cancelled"),
    ]

    meeting = models.ForeignKey(
        GroupMeeting,
        on_delete=models.CASCADE,
        related_name="screen_share_requests",
    )

    requested_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="meeting_screen_share_requests",
    )

    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default="pending",
    )

    requested_at = models.DateTimeField(
        auto_now_add=True,
    )

    reviewed_at = models.DateTimeField(
        null=True,
        blank=True,
    )

    reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="reviewed_screen_share_requests",
    )

    class Meta:
        ordering = ["requested_at"]

        constraints = [
            # A developer cannot submit multiple pending
            # requests for the same meeting.
            models.UniqueConstraint(
                fields=["meeting", "requested_by"],
                condition=models.Q(status="pending"),
                name="unique_pending_screen_share_request",
            ),
        ]

    def clean(self):
        """Validate screen-sharing request information."""
        super().clean()

        if not self.meeting_id or not self.requested_by_id:
            return

        if self.meeting.status != "active":
            raise ValidationError(
                "Screen-sharing requests require an active meeting."
            )

        if self.status == "pending" and self.reviewed_at is not None:
            raise ValidationError(
                "Pending requests cannot have a review time."
            )

    def save(self, *args, **kwargs):
        """Validate requests before saving."""
        self.full_clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return (
            f"Screen-sharing request by {self.requested_by_id} "
            f"({self.status})"
        )